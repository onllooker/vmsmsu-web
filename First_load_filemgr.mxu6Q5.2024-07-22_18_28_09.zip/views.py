from flask_admin.contrib.sqla import ModelView
from wtforms import SelectField
from models import db, Laboratory, Employee

class EmployeeView(ModelView):
    column_formatters = {
        'laboratory': lambda v, c, m, p: m.laboratory.name if m.laboratory else None
    }

    form_overrides = {
        'degree': SelectField,
    }

    form_args = {
        'degree': {
            'choices': ['к.х.н.', 'д.х.н.', 'член корр. РАН', 'академик РАН']
        },
    }

    column_list = ['name', 'adm', 'position','decription', 'degree', 'istina', 'laboratory', 'email',' zav_kaf', 'phone']
    column_labels = {
        'name': 'ФИО',
        'adm': 'Администрация',
        'laboratory': 'Лаборатория',
        'position': 'Должность',
        'degree': 'Степень',
        'phone': 'Телефон',
        'istina': 'IRID',
        'email': 'E-mail',
        'zav_kaf':'Заведующий кафедрой',
        'decription':'Описание'
    }

class LaboratoryView(ModelView):
    can_create = False
    can_delete = False

    column_list = ['name','short_name','short_list_field','list_field','description']
    column_labels = {
        'name':'Название лаборатории',
        'short_name':'ID',
        'short_list_field':'Список направлений (кратко)',
        'list_field':'Список направлений',
        'description':'Описание лаборатории',
    }


def register_admin_views(admin):
    admin.add_view(LaboratoryView(Laboratory, db.session, name='Лаборатории'))
    admin.add_view(EmployeeView(Employee, db.session, name='Сотрудники'))