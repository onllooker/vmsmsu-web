from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Laboratory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True)
    short_name = db.Column(db.String(100), unique=True)
    short_list_field = db.Column(db.Text())
    list_field = db.Column(db.Text())
    description = db.Column(db.Text())
    employees = db.relationship('Employee', back_populates='laboratory')

class Employee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(40))
    position = db.Column(db.String(25))
    degree = db.Column(db.String(25))
    phone = db.Column(db.String(30))
    email = db.Column(db.String(100))
    istina = db.Column(db.String, unique=True)
    description = db.Column(db.Text())
    laboratory_id = db.Column(db.Integer, db.ForeignKey('laboratory.id'))
    laboratory = db.relationship('Laboratory', back_populates='employees')
    adm = db.Column(db.Boolean, unique=False, default=False)
    zav_caf = db.Column(db.Boolean, unique=False, default=False)
  