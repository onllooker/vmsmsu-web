class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://u2722655_admin:xW5eO0wM7mqX6mM5@31.31.196.163:3306/u2722655_default'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'supersecretkey'