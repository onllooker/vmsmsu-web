contact_card_list = [
    {
        'name': 'Ярославов А.А.',
        'dolzh': 'зав. кафедрой ВМС',
        'room': '426, 427',
        'phone': '+7 (495) 939-55-83',
        'email': 'yaroslav@belozersky.msu.ru'
    },
    {
        'name': 'Черникова Е.В.',
        'dolzh': 'зам. зав. каф. по учебной работе',
        'room': '122',
        'phone': '+7 (495) 939-54-06',
        'email': ' chernikova_elena@mail.ru'
    },
    {
        'name': 'Ефимова А.А.',
        'dolzh': 'зам. зав. каф. по научной работе',
        'room': '228',
        'phone': '+7 (495) 939-31-16',
        'email': 'ephimova@belozersky.msu.ru'
    },
    {
        'name': 'Ужинова Л.Д.',
        'dolzh': 'зам. зав. каф. по учебной работе',
        'room': '526',
        'phone': '+7 (495) 939-31-32',
        'email': 'balaklavax@yandex.ru'
    },
]
