from flask import Blueprint, render_template, jsonify, current_app
from models import Laboratory, Employee
from contact_card import contact_card_list

# Создаем Blueprint
bp = Blueprint('routes', __name__)


@bp.route('/')
@bp.route('/main')
def main():
    return render_template("main.html")


@bp.route('/history')
def history():
    return render_template("conf.html", active_page='hist')


@bp.route('/laboratories')
def laboratories():
    try:
        laboratories = Laboratory.query.all()
        return render_template("laboratories.html", laboratories=laboratories, active_page='laboratories')
    except Exception as e:
        current_app.logger.error(f'Error occurred while querying laboratories: {e}')
        return jsonify({"error": "An error occurred while retrieving laboratories"}), 500


@bp.route('/laboratories/<lab_name>')
def lab(lab_name):
    laboratory = Laboratory.query.filter_by(short_name=lab_name).first()
    employees = laboratory.employees if laboratory else []
    return render_template("lab_template.html", laboratory=laboratory, employees=employees, active_page='laboratories')

@bp.route('/study')
def study():
    return render_template("educational_materials.html", active_page='stud')

@bp.route('/getTable/<class_id>')
def get_table(class_id):
    if class_id in time_table:
        class_data = time_table[class_id]
        return jsonify(class_data)
    else:
        return jsonify({"error": "Class not found"}), 404

@bp.route('/conf')
def conf():
    return render_template("conf.html", active_page='conf')

@bp.route('/employees')
def empl():
    current_app.logger.info('Accessing /employees route')
    try:
        laboratories = Laboratory.query.all()
        current_app.logger.info('Fetched laboratories from database')
        
        all_employees = Employee.query.all()
        current_app.logger.info('Fetched employees from database')
        
        lab_employees_data = {}
        for lab in laboratories:
            lab_employees_data[lab.name] = [emp for emp in all_employees if emp.laboratory_id == lab.id]
        
        administration = [emp for emp in all_employees if emp.adm]
        
        current_app.logger.info('Successfully processed employee data')
        return render_template("employees.html", data=lab_employees_data, administration=administration, active_page='employ')
    except Exception as e:
        current_app.logger.error(f'Error occurred: {e}')
        return jsonify({"error": "An error occurred"}), 500

@bp.route('/contacts')
def contact():
    return render_template("contacts.html", contact_card_list=contact_card_list, active_page='contact')

@bp.route('/get_employee_data/<string:istina_id>')
def get_employee_data(istina_id):
    employee = Employee.query.filter_by(istina=istina_id).first()
    if not employee:
        return jsonify({"error": "Employee not found"}), 404

    data = {
        "name": employee.name,
        "position": employee.position,
        "degree": employee.degree,
    }

    data = {key: value for key, value in data.items() if value}

    return jsonify(data)



