from flask import Flask
from flask_admin import Admin
from config import Config
from models import db
from views import register_admin_views
from routes import bp
import logging
from logging.handlers import RotatingFileHandler

application = Flask(__name__)
application.config.from_object(Config)

db.init_app(application)
admin = Admin(application, name='Lab Management', template_mode='bootstrap4')
register_admin_views(admin)

application.register_blueprint(bp)

if __name__ == '__main__':
    handler = RotatingFileHandler('error.log', maxBytes=10000, backupCount=1)
    handler.setLevel(logging.INFO)
    application.logger.addHandler(handler)
    application.run(debug=True)